# map_ex_1

Flutter project with Google Maps.

## Getting Started

Update AndroidManifest.xml in android -> app -> src -> main -> AndroidManifest.xml with your api key for google maps in order for this code to work
