package com.example.map_ex_1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
