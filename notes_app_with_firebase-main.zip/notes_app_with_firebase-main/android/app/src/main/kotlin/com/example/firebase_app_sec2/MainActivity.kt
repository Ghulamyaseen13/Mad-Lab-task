package com.example.firebase_app_sec2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
