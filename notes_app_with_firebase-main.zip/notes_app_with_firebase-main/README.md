# Notes App with User Authentication and Firestore

Flutter project to demonstrate how to incorporate firebase_authand cloud_firestore.

## Getting Started

This project is a starting point for a Flutter application with firebase.

